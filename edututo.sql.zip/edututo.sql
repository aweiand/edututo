-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Mai 15, 2011 as 10:50 PM
-- Versão do Servidor: 5.1.56
-- Versão do PHP: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `edututo`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `administradores`
--

DROP TABLE IF EXISTS `administradores`;
CREATE TABLE IF NOT EXISTS `administradores` (
  `admid` int(4) NOT NULL AUTO_INCREMENT,
  `admnome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `admlogin` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `admsenha` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `admemail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `admprof` int(4) NOT NULL,
  PRIMARY KEY (`admid`),
  UNIQUE KEY `admlogin` (`admlogin`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `administradores`
--

INSERT INTO `administradores` (`admid`, `admnome`, `admlogin`, `admsenha`, `admemail`, `admprof`) VALUES
(1, 'administrador de teste', 'asd', 'asd', 'emailadm@testeadm.com', 0),
(3, 'teste de administrador', 'a', 'a', 'adm@teste.com', 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `alunos`
--

DROP TABLE IF EXISTS `alunos`;
CREATE TABLE IF NOT EXISTS `alunos` (
  `aid` int(4) NOT NULL AUTO_INCREMENT,
  `anome` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alogin` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `asenha` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `aemail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`aid`),
  UNIQUE KEY `alogin` (`alogin`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Extraindo dados da tabela `alunos`
--

INSERT INTO `alunos` (`aid`, `anome`, `alogin`, `asenha`, `aemail`) VALUES
(1, 'teste de aluno', 'asd', 'asd', 'email@teste'),
(2, 'testando aluno de novo', 'a', 'a', 'testedenovo@email.com');

-- --------------------------------------------------------

--
-- Estrutura da tabela `alunos_cursos`
--

DROP TABLE IF EXISTS `alunos_cursos`;
CREATE TABLE IF NOT EXISTS `alunos_cursos` (
  `acaid` int(4) NOT NULL,
  `accid` int(4) NOT NULL,
  `acnotafinal` float NOT NULL DEFAULT '-1',
  `acdataprova` date DEFAULT NULL,
  `acdatainicio` date DEFAULT NULL,
  `acnumprovas` smallint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`acaid`,`accid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `alunos_cursos`
--

INSERT INTO `alunos_cursos` (`acaid`, `accid`, `acnotafinal`, `acdataprova`, `acdatainicio`, `acnumprovas`) VALUES
(1, 1, 2, '2011-05-12', '2011-05-12', 1),
(1, 3, 1, '2011-05-12', '2011-05-12', 3),
(2, 1, -1, NULL, '2011-05-15', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `arquivos`
--

DROP TABLE IF EXISTS `arquivos`;
CREATE TABLE IF NOT EXISTS `arquivos` (
  `arqid` int(4) NOT NULL AUTO_INCREMENT,
  `arqcid` int(4) NOT NULL,
  `arqdesc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `arqcaminho` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `arqdata` date NOT NULL,
  PRIMARY KEY (`arqid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Extraindo dados da tabela `arquivos`
--

INSERT INTO `arquivos` (`arqid`, `arqcid`, `arqdesc`, `arqcaminho`, `arqdata`) VALUES
(10, 1, 'teste 1', '../arquivos/15052011224449.pdf', '2011-05-15'),
(11, 1, 'teste 2', '../arquivos/15052011224459.doc', '2011-05-15');

-- --------------------------------------------------------

--
-- Estrutura da tabela `conteudos`
--

DROP TABLE IF EXISTS `conteudos`;
CREATE TABLE IF NOT EXISTS `conteudos` (
  `conid` int(4) NOT NULL AUTO_INCREMENT,
  `cid` int(4) NOT NULL,
  `condes` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contipo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `contxt` text COLLATE utf8_unicode_ci NOT NULL,
  `conarq` blob,
  `condata` date NOT NULL,
  PRIMARY KEY (`conid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Extraindo dados da tabela `conteudos`
--

INSERT INTO `conteudos` (`conid`, `cid`, `condes`, `contipo`, `contxt`, `conarq`, `condata`) VALUES
(2, 3, 'as terras', 'conteudo 3', 'as terras sao terras\r\n\r\nterras\r\n\r\n\r\nterras', NULL, '2011-05-15'),
(9, 1, 'o mar', 'o mar', 'o mar e azul', NULL, '2011-05-15'),
(10, 3, 'as terras2', 'as terras2', 'as terras sao terras\r\n\r\nterras\r\n\r\n\r\nterrasas terras sao terras\r\n\r\nterras\r\n\r\n\r\nterrasas terras sao terras\r\n\r\nterras\r\n\r\n\r\nterras', NULL, '2011-05-15');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cursos`
--

DROP TABLE IF EXISTS `cursos`;
CREATE TABLE IF NOT EXISTS `cursos` (
  `cid` int(4) NOT NULL AUTO_INCREMENT,
  `cdesc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `cnivel` int(4) NOT NULL,
  PRIMARY KEY (`cid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Extraindo dados da tabela `cursos`
--

INSERT INTO `cursos` (`cid`, `cdesc`, `cnivel`) VALUES
(1, 'Cores do Mar', 1),
(3, 'Cores da Terra', 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `perguntas`
--

DROP TABLE IF EXISTS `perguntas`;
CREATE TABLE IF NOT EXISTS `perguntas` (
  `pid` int(4) NOT NULL AUTO_INCREMENT,
  `ppergunta` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

--
-- Extraindo dados da tabela `perguntas`
--

INSERT INTO `perguntas` (`pid`, `ppergunta`) VALUES
(1, 'Que cor é o mar'),
(2, 'Que cor e a grama'),
(3, 'Cor da areia'),
(4, 'cor da lagoa');

-- --------------------------------------------------------

--
-- Estrutura da tabela `provas`
--

DROP TABLE IF EXISTS `provas`;
CREATE TABLE IF NOT EXISTS `provas` (
  `pcid` int(4) NOT NULL,
  `ppid` int(4) NOT NULL,
  `prid` int(4) NOT NULL,
  `pcerta` smallint(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`pcid`,`ppid`,`prid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Extraindo dados da tabela `provas`
--

INSERT INTO `provas` (`pcid`, `ppid`, `prid`, `pcerta`) VALUES
(1, 1, 1, 1),
(1, 1, 2, 0),
(1, 4, 1, 0),
(1, 4, 2, 1),
(1, 4, 3, 0),
(1, 4, 4, 0),
(3, 2, 1, 0),
(3, 2, 2, 1),
(3, 2, 3, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `respostas`
--

DROP TABLE IF EXISTS `respostas`;
CREATE TABLE IF NOT EXISTS `respostas` (
  `rid` int(4) NOT NULL AUTO_INCREMENT,
  `rresposta` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`rid`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Extraindo dados da tabela `respostas`
--

INSERT INTO `respostas` (`rid`, `rresposta`) VALUES
(1, 'azul'),
(2, 'verde'),
(3, 'amarelo'),
(4, 'laranja');
